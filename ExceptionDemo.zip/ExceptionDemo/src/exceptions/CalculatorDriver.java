/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exceptions;

/**
 *
 * @author s530472
 */
public class CalculatorDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try{
        Calculator calc = new Calculator(8,0);
        System.out.println("Sum:"+calc.add());
        System.out.println("Diff:"+calc.subtract());
        System.out.println("Product:"+calc.mul());
        System.out.println("I am still testing");
        System.out.println("Quotient:"+calc.div());
        System.out.println("I am done with testing");
        }
        catch(ArithmeticException e){
            System.out.println(e.getMessage()+e);
        }
        catch(DivisibleByZeroException e){
            System.out.println(e.getMessage()+e);
        }
    }
   
}
