    /*
     * To change this license header, choose License Headers in Project Properties.
     * To change this template file, choose Tools | Templates
     * and open the template in the editor.
     */
    package exceptions;

    /**
     *
     * @author s530472
     */
    public class Calculator {
        int numberA;
        int numberB;

        public Calculator(int numberA, int numberB) {
            this.numberA = numberA;
            this.numberB = numberB;
        }
        public int add(){
            return numberA+numberB;
        }
        public int subtract(){
            return numberA-numberB;
        }
        public int mul(){
            return numberA*numberB;
        }
        public int div() throws DivisibleByZeroException{
            if(numberB==0){
            throw new DivisibleByZeroException("divided by zero is not possible");

    //throw new ArithmeticException("Make sure you give proper input");
            }
            return numberA/numberB;
        }
    }
